from distutils.core import setup
setup(
name = "ExcelWrite",
version = "1.1.0",
py_modules = ["ExcelWrite"],
author ="GwangWoon",
author_email ="highlighter9@naver.com",
description="Excel Write Module",
)